var _       = require('lodash');
var debug   = require('debug')('kumladi-api:controllers:posts');
var Posts     = require('../../models/post');
var id=require('mongoose').Types.ObjectId;
debug('Initialising the comment controller');

/**
* @params req.params.parentID This will hold the ID of the parent post.
* @params req.body.student_number This will hold the student number of the student who he appending to the post.
* @params req.body.content This will be the content that will be attached to the post.
* @params req.body.tag_list This will be the array of chosen tags, which will be attached to the post.
* @todo The post will be created and then linked to the parent post.
* @return A JSON object will be returned. If the appending operation was successful then the JSON object will carry the new post's ID, otherwise an error message will be in the JSON object.
*/
module.exports.appendPost=function(req,res,next){
	Posts.find({"_id":req.params.parentID},function(err,post){
		if(err)
		{
			console.log("An error was encoutered",err);
			res.status(504).send({"data":err});
		}
		else if(!post)
		{
			console.log("Failed to find the post");
			res.status(405).send({"data":"Failed to find the post"});
		}
		else
		{
			var newId=new id();
			var doc=new Posts({
				heading:post.heading,
				level_number:post.level_number+1,
				_id:newId,
				parent_ID:post._id,
				content:req.body.content,
				student_number:req.body.student_number,
				timestamp: new Date(),
				course_code:post.course_code,
				tag_list:req.body.tag_list,
				child_list:[]
				
			});
			doc.save(function(err,savedDoc){
				if(err)
				{
					console.log("There was an error saving the document",err);
					res.status(405).send({"data":err});
				}
				else if(!savedDoc)
				{
					console.log("Document failed to save");
					res.status(504).send({"data":"Failed to save the document"});
				}
				else
				{
					console.log("Successfully saved document");
					Posts.findByIdAndUpdate(savedDoc.parent_ID,{"$push":{"child_list":savedDoc._id}},function(err,newDoc){
						if(err)
						{
							console.log("Encountered an error when trying to find and update the parent post",err);
							res.status(504).send({"data":"Failed to find and update parent post"});
						}
						else if(!newDoc)
						{
							console.log("Failed to update the parent post");
							res.status(504).send({"data":"Failed to update the parent post"});
						}
						else
						{
							console.log("Successfully appended to post");
							res.status(200).send({"data":"Successfully appended to post"});
						}
					});
				}
			});
		}
	});
};

/**
* @params None
* @todo All posts will be sorted by the dates created and the most recent five posts will be picked.
* @return A JSON object will be returned. If documents were found then an array with them will be returned, otherwise there will be no array.
*/ 
module.exports.getLatestPosts=function(req,res,next){
	var docs[];
	console.log("Finding all documents");
	Posts.find().limit(5).sort({"timestamp":-1}).forEach(function(doc){
		var pass={
			postID:doc._id,
			heading:doc.heading
		};
		docs.push(pass);
	});
	if(docs.length==0)
	{
		console.log("Could not find any documents in the database");
		res.status(504).send("data":"Could not find any documents in the database");
	}
	else
	{
		var result={first:docs,data:"Successfully found the most recent posts"};
		res.status(200).send(result);
	}
};

/**
* @params req.params.postID The ID of the post.
* @todo All the child posts of the post will be found and sorted in ascending order according to their timestamps. The documents' IDs and heading will be stored in an array.
* @return A JSON object will be returned. If successful then the object will contain an array of JSON objects, otherwise there will be an error message.
*/ 
module.exports.getChildPosts=function(req,res,next){
	if(req.params.postID)
	{
		var docs[];
		Posts.find({"parent_ID":req.params.parent_ID}).forEach(function(doc){
			docs.push({
				heading:doc.heading,
				postID:doc._id
			});
		});
		if(docs.length==0)
		{
			console.log("No documents were found");
		}
		else 
		{
			console.log("Documents found and saved");
		}
		res.status(200).send({result:docs});
	}
	else
	{
		console.log("No parameters found");
		res.status(405).send({data:"No parameters found"});
	}
};

/**
* @params req.params.course_code The course code for the posts to be found.
* @todo All the posts will be sorted in ascending order then their IDs and heading will be returned.
* @return A JSON object will be returned. If successful then every index of the array will contain a JSON object.
*/ 
module.exports.getPosts=function(req,res,next){
	var docs=[];
	if(req.params.course_code)
	{
		Posts.find({"level_number":0,"course_code":req.params.course_code}).sort({"timestamp":-1}).forEach(function(doc){
			if(doc)
			{
				docs.push({
					postID:doc._id,
					heading:doc.heading,
					level:0,
					children:[]
				});
			}
		});
		if(docs.length==0)
		{
			console.log("No posts");
			res.status(200).send({data:"No posts"});
		}
		else
		{
			var i=0;
			for(;i<docs.length;i++)
			{
				dfs(docs[i]);
			}
		}
	}
	else
	{
		console.log("Parameters missing");
		res.status(405).send({data:"Parameters missing"});
	}
};

var dfs=function(arr){
	if(arr)
	{
		var i=0;
		for(;i<arr.length;i++)
		{
			Posts.find({"parent_ID":arr[i].postID}).sort({"timestamp":-1}).forEach(function(doc){
				arr[i].children.push({
					postID:doc._id,
					heading:doc.heading,
					level:doc.level_number,
					children:[]
				});
			});
		}
		for(i=0;i<arr.length;i++)
		{
			dfs(arr[i].children);
		}
	}
};

module.exports.movePost=function(req,res,next){
	if(req.params.parentID&&req.params.postID)
	{
		Posts.findById(req.params.postID,function(err,obj){
			if(err)
			{
				console.log("Encountered an error",err);
				res.status(504).send({data:err});
			}
			else if(!obj)
			{
				console.log("Failed to find post");
				res.status(200).send({data:"Failed to find post"});
			}
			else
			{
				Posts.findByIdAndUpdate(req.params.parentID,{"$push":{"child_list":obj._id}},function(err,newObj){
					if(err)
					{
						console.log("Encountered error when updating parent",err);
						res.status(504).send({data:"Encountered error when updating parent"});
					}
					else if(!newObj)
					{
						console.log("Failed to update parent post");
						res.status(504).send({data:"Failed to update parent post"});
					}
					else
					{
						Posts.findByIdAndUpdate(newObj.parent_ID,{"$pull":{"child_list":obj._id}},function(err,u){
							if(err)
							{
								console.log("Encountered error",err);
							}
						});
						var newLevel=obj.level_number-newObj.level_number;
						Posts.findByIdAndUpdate(obj._id,{"level_number":obj.level_number-newLevel},function(err,newObj){
							if(err)
							{
								console.log("Encountered error",err);
								res.status(504).send({data:err});
							}
							else if(!newObj)
							{
								console.log("Failed to update post level");
								res.status(504).send({data:"Failed to update post level"});
							}
							else
							{
								moveDFS(newObj,newLevel);
							}
						});
					}
				});
				
			}
		});
	}
	else
	{
		console.log("Parameters missing");
		res.status(405).send({data:"Parameters missing"});
	}
};

var moveDFS=function(obj,level){
	if(obj)
	{
		var docs=[];
		Posts.find({"parent_ID":obj._id}).forEach(function(doc){
			Posts.update({"_id":doc},{"level_number":level_number-level},function(err,newDoc){
				if(err)
				{
					console.log("Encountered error while updating levels",err);
				}
				else if(!newDoc)
				{
					console.log("Failed to update post level");
				}
				else
				{
					docs.push(newDoc);
				}
			});
		});
		var i=0;
		for(;i<docs.length;i++)
		{
			moveDFS(docs[i],level);
		}
	}
};