var _       = require('lodash');
var debug   = require('debug')('kumladi-api:controllers:posts');
var Posts     = require('../../models/post');
var id=require('mongoose').Types.ObjectId;
debug('Initialising the comment controller');

/**
* @params req.params.parentID This will hold the ID of the parent post.
* @params req.body.student_number This will hold the student number of the student who he appending to the post.
* @params req.body.content This will be the content that will be attached to the post.
* @params req.body.tag_list This will be the array of chosen tags, which will be attached to the post.
* @todo The post will be created and then linked to the parent post.
* @return A JSON object will be returned. If the appending operation was successful then the JSON object will carry the new post's ID, otherwise an error message will be in the JSON object.
*/
module.exports.appendPost=function(req,res,next){
	Posts.find({"_id":req.params.parentID},function(err,post){
		if(err)
		{
			console.log("An error was encoutered",err);
			res.status(504).send({"data":err});
		}
		else if(!post)
		{
			console.log("Failed to find the post");
			res.status(405).send({"data":"Failed to find the post"});
		}
		else
		{
			var newId=new id();
			var doc=new Posts({
				heading:post.heading,
				level_number:post.level_number+1,
				_id:newId,
				parent_ID:post._id,
				content:req.body.content,
				student_number:req.body.student_number,
				timestamp: new Date(),
				course_code:post.course_code,
				tag_list:req.body.tag_list,
				child_list:[]
				
			});
			doc.save(function(err,savedDoc){
				if(err)
				{
					console.log("There was an error saving the document",err);
					res.status(405).send({"data":err});
				}
				else if(!savedDoc)
				{
					console.log("Document failed to save");
					res.status(504).send({"data":"Failed to save the document"});
				}
				else
				{
					console.log("Successfully saved document");
					Posts.findByIdAndUpdate(savedDoc.parent_ID,{"$push":{"child_list":savedDoc._id}},function(err,newDoc){
						if(err)
						{
							console.log("Encountered an error when trying to find and update the parent post",err);
							res.status(504).send({"data":"Failed to find and update parent post"});
						}
						else if(!newDoc)
						{
							console.log("Failed to update the parent post");
							res.status(504).send({"data":"Failed to update the parent post"});
						}
						else
						{
							console.log("Successfully appended to post");
							res.status(200).send({"data":"Successfully appended to post"});
						}
					});
				}
			});
		}
	});
};

/**
* @params None
* @todo All posts will be sorted by the dates created and the most recent five posts will be picked.
* @return A JSON object will be returned. If documents were found then an array with them will be returned, otherwise there will be no array.
*/ 
module.exports.getLatestPosts=function(req,res,next){
	var docs[];
	console.log("Finding all documents");
	Posts.find().limit(5).sort({"timestamp":-1}).forEach(function(doc){
		var pass={
			postID:doc._id,
			heading:doc.heading
		};
		docs.push(pass);
	});
	if(docs.length==0)
	{
		console.log("Could not find any documents in the database");
		res.status(504).send("data":"Could not find any documents in the database");
	}
	else
	{
		var result={first:docs,data:"Successfully found the most recent posts"};
		res.status(200).send(result);
	}
};

/**
* @params req.params.postID The ID of the post.
* @todo All the child posts of the post will be found and sorted in ascending order according to their timestamps. The documents' IDs and heading will be stored in an array.
* @return A JSON object will be returned. If successful then the object will contain an array of JSON objects, otherwise there will be an error message.
*/ 
module.exports.getChildPosts=function(req,res,next){
	if(req.params.postID)
	{
		var docs[];
		Posts.find({"parent_ID":req.params.parent_ID}).forEach(function(doc){
			docs.push({
				heading:doc.heading,
				postID:doc._id
			});
		});
		if(docs.length==0)
		{
			console.log("No documents were found");
		}
		else 
		{
			console.log("Documents found and saved");
		}
		res.status(200).send({result:docs});
	}
	else
	{
		console.log("No parameters found");
		res.status(405).send({data:"No parameters found"});
	}
};