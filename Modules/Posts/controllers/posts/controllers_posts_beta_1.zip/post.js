var debug   = require('debug')('kumladi-api:controllers:post');
var Posts     = require('../../models/post');
var mongoose=require('mongoose');
var id=mongoose.Types.ObjectId;
debug('Initialising the post controller');

debug('Exporting method: create');
//Add function here
/**
* @params req.params.course_code The course code.
* @params req.params.content The content to be added.
* @params req.params.heading The heading ofthe post.
* @params req.params.student_number The student number of the creator of the post.
* @params req.params.tag_list The array of the tag lists to be added.
* @todo A post will be created and saved on the database.
* @return A JSON object will be returned. If successful then the post's ID will be in the object.
*/
module.exports.createPost=function(req,res,next){
	if(req.params.course_code&&req.params.content&&req.params.heading&&req.params.student_number&&req.params.tag_list)
	{
		var post=new Posts({
			heading:req.body.heading,
			level_number:0,
			child_list:[],
			parent_ID:null,
			course_code:req.body.course_code,
			timestamp: new Date(),
			student_number:req.body.student_number,
			content:req.body.content,
			tag_list:req.body.tag_list
		});
		// saving the new post
		post.save(function(err, obj){
			if(err)
			{
				console.log("Encountered an error:",err);
				res.status(504).send({"data":err});
			}
			else if(!obj)
			{
				console.log("Failed to save the document");
				res.status(405).send("data":"Failed to save the document");
			}
			else
			{
				res.status(200).send({
					post_ID:obj._id,
					heading:obj.heading
				});
			}
		});
	}
};
/**
* @params req.params.postID The ID of the post to be updated.
* @params req.params.tag_list The taglists to be added.
* @todo The post to be edited will be found using it's ID then the tag list will be updated.
* @return A JSON object will be returned. If successful then it will contain the post's ID, otherwise it an error message will be in the object.
*/
module.exports.editPost=function(req,res,next){
	if(req.params.postID&&req.params.tag_list)
	{
		Posts.findOneAndUpdate({"_id":req.params.postID},{"$push":{"tag_list":req.params.tag_list}},function(err,doc){
			if(err)
			{
				console.log("An error was encountered: ",err);
				res.status(504).send({"data":err});
			}
			else if(!doc)
			{
				console.log("Failed to edit the post");
				res.status(504).send({"data":"Failed to edit the post"});
			}
			else
			{
				res.status(200).send({
					postID:doc._id
				});
			}
		});
	}
	else
	{
		console.log("Parameters were missing");
		res.status(405).send({"data":"Parameters were missing"});
	}
};

/**
* @params req.params.postID The ID of the post to be removed
* @todo The post will be found using it's ID and then removed.
* @return Nothing will be returned.
*/
module.exports.removePost=function(req,res,next){
	if(req.params.postID)
	{
		Posts.remove({"_id":req.param.postID},function(err){
			if(err)
			{
				console.log("Encountered an error: ",err);
			}
		});
	}
};
/**
* @params req.params.course_code The course code for the posts to be found.
* @todo All the level-0 posts will be sorted in ascending order then their IDs and heading will be returned.
* @return A JSON object will be returned. If successful then every index of the array will contain a JSON object.
*/ 
module.exports.getAllPosts=function(req,res,next){
	var docs[];
	if(req.params.course_code)
	{
		Posts.find({"level_number":0,"course_code":req.params.course_code}).sort({"timestamp":-1}).forEach(function(doc){
			if(doc)
			{
				docs.push({
					postID:doc._id,
					heading:doc.heading,
					level:0
				});
			}
		});
		if(docs.length==null||docs.length==0)
		{
			console.log("No posts were found");
		}
		else
		{
			console.log("Found all the level-0 posts");
		}
		res.status(200).send({result:docs});
	}
	else
		res.status(405).send("No parameters sent");
};