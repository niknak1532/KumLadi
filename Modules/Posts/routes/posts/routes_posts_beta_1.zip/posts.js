var debug       = require('debug')('kumladi-api:routes:posts');
var express     = require('express');
var posts   = require('../../controllers/posts/posts');

debug('Creating post router');
var router = express.Router();


//Add routes (to functions) here
router.post('/addPost',posts.appendPost);
router.post('/getRecentPosts',posts.getLatestPosts);
router.post('/getPosts',posts.getChildPosts);

debug('post router exported');
module.exports = router;

