var debug       = require('debug')('kumladi-api:routes:posts');
var express     = require('express');
var posts   = require('../../controllers/posts/posts');

debug('Creating post router');
var router = express.Router();


//Add routes (to functions) here
router.post('/addPost/:parentID',posts.appendPost);
router.get('/getLatestPosts',posts.getLatestPosts);
router.post('/getPosts/:postID',posts.getChildPosts);
router.post('/getPosts/:course_code',posts.getPosts);
router.post('/movePost/:postID/:parentID',posts.movePost);
debug('post router exported');
module.exports = router;

