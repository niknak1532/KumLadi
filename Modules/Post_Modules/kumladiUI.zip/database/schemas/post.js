// var mongoose = require('mongoose');
//
// var ChatSchema = new mongoose.Schema({
//     room: String,
//     nickname: String,
//     message: String,
//     updated_at: { type: Date, default: Date.now },
// });
//
// var Chat = mongoose.model('Chat', ChatSchema);
//
// module.exports = Chat;


var mongoose    = require('mongoose');

var Post_module = new mongoose.Schema({
    heading: {
        type: String
    },

    level_number: {
        type: Number
    },

    child_list: {
        type: []
    },

    tag_list: {
        type: [String]
    },

    parent_ID: {
        type: mongoose.Schema.Types.Mixed,
        ref:'Post_module'
    },
// have a default preference
    content: {
        type: String
    },

    course_code: {
        type: String
    },

    student_number: {
        type: String
    },

    timestamp : {
        type: Date,
        default: Date.now
    },
    visibility:{
        type:Boolean,
        default: true
    }
});

var Post = mongoose.model('postModule', Post_module);
module.exports = Post;
