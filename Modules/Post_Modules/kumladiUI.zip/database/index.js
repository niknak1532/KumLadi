// var mongoose = require('mongoose');
// var ChatModel = require('./schemas/chat');
//
// mongoose.Promise = global.Promise;
//
// mongoose.connect('mongodb://localhost/mean-chat')
//   .then(() =>  console.log('connection successful'))
//   .catch((err) => console.error(err));
//
// exports.chat = ChatModel;

var mongoose = require('mongoose');
var postModel = require('./schemas/post');

mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/post-db')
    .then(() => console.log('Connection successful'))
.catch((err) => console.log(err));

exports.posts = postModel;