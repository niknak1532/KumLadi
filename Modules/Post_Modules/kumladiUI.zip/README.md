# MeanChat

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.2.7.  It is the results of following the tutorial [here](https://www.djamware.com/post/58e0d15280aca75cdc948e4e/building-chat-application-using-mean-stack-angular-4-and-socketio).

## Installation

git clone this repository.  Then, from the root:

```
npm install
ng build
npm start
```
For the last step you can do this instead:
```
nodemon
```
However, when you change the angular, you have to do an `ng build`.

To use the chat, open two browsers at:

http://localhost:3000/

