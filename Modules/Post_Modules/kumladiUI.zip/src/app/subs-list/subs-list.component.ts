import { Component, OnInit, Input } from '@angular/core';
// import {CPU} from '../cpu';

@Component({
  selector: 'app-subs-list',
  templateUrl: './subs-list.component.html',
  styleUrls: ['./subs-list.component.css']
})
export class SubsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
