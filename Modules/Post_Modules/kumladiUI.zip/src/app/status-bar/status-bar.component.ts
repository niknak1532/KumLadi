import { Component, OnInit, Input } from '@angular/core';
// import {CPU} from '../cpu';

@Component({
  selector: 'app-status-bar',
  templateUrl: './status-bar.component.html',
  styleUrls: ['./status-bar.component.css']
})
export class StatusBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
